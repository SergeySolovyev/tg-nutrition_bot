import asyncio
import json
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Dict, Optional


def today_key() -> str:
    return date.today().isoformat()


@dataclass
class DataStore:
    path: Path
    _lock: asyncio.Lock

    @classmethod
    def create(cls, path: str) -> "DataStore":
        return cls(path=Path(path), _lock=asyncio.Lock())

    async def _load_nolock(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {"users": {}}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            # if file is corrupted, keep a backup and start fresh
            bak = self.path.with_suffix(".corrupted.json")
            self.path.replace(bak)
            return {"users": {}}

    async def _save_nolock(self, data: Dict[str, Any]) -> None:
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    async def get_user(self, user_id: int) -> Dict[str, Any]:
        async with self._lock:
            data = await self._load_nolock()
            users = data.setdefault("users", {})
            u = users.setdefault(str(user_id), {})
            u.setdefault("profile", {})
            u.setdefault("days", {})
            return u

    async def set_profile(self, user_id: int, profile: Dict[str, Any]) -> None:
        async with self._lock:
            data = await self._load_nolock()
            users = data.setdefault("users", {})
            u = users.setdefault(str(user_id), {"profile": {}, "days": {}})
            u["profile"] = profile
            u.setdefault("days", {})
            await self._save_nolock(data)

    async def get_day(self, user_id: int, day: Optional[str] = None) -> Dict[str, Any]:
        day = day or today_key()
        async with self._lock:
            data = await self._load_nolock()
            u = data.setdefault("users", {}).setdefault(str(user_id), {"profile": {}, "days": {}})
            days = u.setdefault("days", {})
            d = days.setdefault(day, {"logged_water_ml": 0, "logged_calories": 0, "burned_calories": 0, "workout_extra_water_ml": 0})
            await self._save_nolock(data)
            return d

    async def add_water(self, user_id: int, ml: int, day: Optional[str] = None) -> None:
        day = day or today_key()
        async with self._lock:
            data = await self._load_nolock()
            d = data.setdefault("users", {}).setdefault(str(user_id), {"profile": {}, "days": {}}) \
                    .setdefault("days", {}).setdefault(day, {"logged_water_ml": 0, "logged_calories": 0, "burned_calories": 0, "workout_extra_water_ml": 0})
            d["logged_water_ml"] = int(d.get("logged_water_ml", 0)) + int(ml)
            await self._save_nolock(data)

    async def add_food(self, user_id: int, calories: float, day: Optional[str] = None) -> None:
        day = day or today_key()
        async with self._lock:
            data = await self._load_nolock()
            d = data.setdefault("users", {}).setdefault(str(user_id), {"profile": {}, "days": {}}) \
                    .setdefault("days", {}).setdefault(day, {"logged_water_ml": 0, "logged_calories": 0, "burned_calories": 0, "workout_extra_water_ml": 0})
            d["logged_calories"] = float(d.get("logged_calories", 0)) + float(calories)
            await self._save_nolock(data)

    async def add_workout(self, user_id: int, burned: float, extra_water_ml: int, day: Optional[str] = None) -> None:
        day = day or today_key()
        async with self._lock:
            data = await self._load_nolock()
            d = data.setdefault("users", {}).setdefault(str(user_id), {"profile": {}, "days": {}}) \
                    .setdefault("days", {}).setdefault(day, {"logged_water_ml": 0, "logged_calories": 0, "burned_calories": 0, "workout_extra_water_ml": 0})
            d["burned_calories"] = float(d.get("burned_calories", 0)) + float(burned)
            d["workout_extra_water_ml"] = int(d.get("workout_extra_water_ml", 0)) + int(extra_water_ml)
            await self._save_nolock(data)

    async def reset_today(self, user_id: int) -> None:
        async with self._lock:
            data = await self._load_nolock()
            u = data.setdefault("users", {}).setdefault(str(user_id), {"profile": {}, "days": {}})
            u.setdefault("days", {})[today_key()] = {"logged_water_ml": 0, "logged_calories": 0, "burned_calories": 0, "workout_extra_water_ml": 0}
            await self._save_nolock(data)
