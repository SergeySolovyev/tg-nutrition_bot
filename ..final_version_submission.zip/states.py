from aiogram.fsm.state import State, StatesGroup


class Profile(StatesGroup):
    weight = State()
    height = State()
    age = State()
    activity = State()
    city = State()
    calorie_goal = State()


class FoodLog(StatesGroup):
    waiting_grams = State()


class WorkoutLog(StatesGroup):
    waiting_type = State()
    waiting_minutes = State()
