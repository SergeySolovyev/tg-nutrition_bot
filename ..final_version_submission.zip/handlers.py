from __future__ import annotations

import logging
from typing import Optional

from aiogram import Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from calc import (
    calc_calorie_goal,
    calc_water_goal_ml,
    workout_burned_calories,
    workout_extra_water_ml,
)
from config import DATA_PATH
from states import FoodLog, Profile, WorkoutLog
from storage import DataStore
from utils import get_city_temperature_c, search_openfoodfacts

logger = logging.getLogger(__name__)


router = Router()

# Хранилище для данных пользователей (простой json-файл)
store = DataStore.create(DATA_PATH)


def parse_int(s: str) -> Optional[int]:
    try:
        return int(str(s).strip())
    except Exception:
        return None


def parse_float(s: str) -> Optional[float]:
    try:
        return float(str(s).strip().replace(",", "."))
    except Exception:
        return None


async def ensure_profile(user_id: int) -> Optional[dict]:
    u = await store.get_user(user_id)
    prof = u.get("profile") or {}
    required = ["weight_kg", "height_cm", "age", "activity_min", "city", "calorie_goal"]
    if all(k in prof and prof[k] is not None for k in required):
        return prof
    return None


def progress_text(
    water_goal_base: int,
    workout_extra_water: int,
    cal_goal: int,
    logged_water: int,
    logged_cal: float,
    burned: float,
) -> str:
    water_goal = int(water_goal_base) + int(workout_extra_water)
    remaining_water = max(0, water_goal - logged_water)
    balance = logged_cal - burned  # net consumed

    extra_line = (
        f"- Доп. цель из-за тренировок: {int(workout_extra_water)} мл.\n" if workout_extra_water else ""
    )

    return (
        "📊 Прогресс:\n"
        "Вода:\n"
        f"- Выпито: {logged_water} мл из {water_goal} мл.\n"
        f"{extra_line}"
        f"- Осталось: {remaining_water} мл.\n\n"
        "Калории:\n"
        f"- Потреблено: {logged_cal:.0f} ккал из {cal_goal} ккал.\n"
        f"- Сожжено: {burned:.0f} ккал.\n"
        f"- Баланс: {balance:.0f} ккал."
    )


# -----------------------
# /start, /help
# -----------------------


@router.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        "Привет! Я бот для расчёта нормы воды/калорий и трекинга.\n\n"
        "Команды:\n"
        "/set_profile — заполнить профиль\n"
        "/log_water <мл> — записать воду\n"
        "/log_food <продукт> — записать еду\n"
        "/log_workout <тип> <мин> — записать тренировку\n"
        "/check_progress — посмотреть прогресс за сегодня\n"
        "/reset_today — обнулить сегодняшние логи\n"
        "/help — помощь"
    )


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(
        "Как это работает:\n"
        "1) /set_profile — задаёшь вес, рост, возраст, активность, город и цель калорий.\n"
        "2) Норма воды = вес*30мл + 500мл за каждые 30 мин активности + добавка за жару (>25°C).\n"
        "3) /log_water — прибавляет выпитую воду.\n"
        "4) /log_food — ищет калории в OpenFoodFacts, потом спрашивает граммы.\n"
        "5) /log_workout — оценивает сожжённые калории и добавляет воду (+200мл/30мин).\n"
        "6) /check_progress — отчёт за сегодня.\n\n"
        "Если что-то не работает — сначала проверь /set_profile."
    )


# -----------------------
# Profile FSM: /set_profile
# -----------------------


@router.message(Command("set_profile"))
async def set_profile(message: Message, state: FSMContext):
    await state.clear()
    await state.set_state(Profile.weight)
    await message.answer("Введите ваш вес (кг):")


@router.message(Profile.weight)
async def profile_weight(message: Message, state: FSMContext):
    w = parse_float(message.text)
    if w is None or w <= 0 or w > 400:
        await message.answer("Вес должен быть числом (кг). Например: 80")
        return
    await state.update_data(weight_kg=w)
    await state.set_state(Profile.height)
    await message.answer("Введите ваш рост (см):")


@router.message(Profile.height)
async def profile_height(message: Message, state: FSMContext):
    h = parse_float(message.text)
    if h is None or h <= 0 or h > 260:
        await message.answer("Рост должен быть числом (см). Например: 180")
        return
    await state.update_data(height_cm=h)
    await state.set_state(Profile.age)
    await message.answer("Введите ваш возраст (лет):")


@router.message(Profile.age)
async def profile_age(message: Message, state: FSMContext):
    a = parse_int(message.text)
    if a is None or a <= 0 or a > 120:
        await message.answer("Возраст должен быть целым числом. Например: 35")
        return
    await state.update_data(age=a)
    await state.set_state(Profile.activity)
    await message.answer("Сколько минут активности в день (в среднем)? Например: 45")


@router.message(Profile.activity)
async def profile_activity(message: Message, state: FSMContext):
    m = parse_int(message.text)
    if m is None or m < 0 or m > 1440:
        await message.answer("Минуты активности должны быть целым числом. Например: 45")
        return
    await state.update_data(activity_min=m)
    await state.set_state(Profile.city)
    await message.answer("В каком городе вы находитесь? (например: Moscow)")


@router.message(Profile.city)
async def profile_city(message: Message, state: FSMContext):
    city = (message.text or "").strip()
    if len(city) < 2:
        await message.answer("Напишите город текстом. Например: Moscow")
        return
    await state.update_data(city=city)
    await state.set_state(Profile.calorie_goal)

    data = await state.get_data()
    suggested = calc_calorie_goal(data["weight_kg"], data["height_cm"], data["age"], data["activity_min"])
    await message.answer(
        "Цель калорий на день.\n"
        f"Я могу рассчитать по формуле: {suggested} ккал.\n"
        "Введите число, или отправьте 0 чтобы принять расчёт:"
    )


@router.message(Profile.calorie_goal)
async def profile_cal_goal(message: Message, state: FSMContext):
    val = parse_int(message.text)
    if val is None:
        await message.answer("Введите целое число, например 2500, или 0 чтобы принять расчёт.")
        return

    data = await state.get_data()
    suggested = calc_calorie_goal(data["weight_kg"], data["height_cm"], data["age"], data["activity_min"])
    cal_goal = suggested if val == 0 else val
    if cal_goal <= 0 or cal_goal > 10000:
        await message.answer("Цель калорий должна быть в разумных пределах. Например 2500 (или 0).")
        return

    profile = {
        "weight_kg": float(data["weight_kg"]),
        "height_cm": float(data["height_cm"]),
        "age": int(data["age"]),
        "activity_min": int(data["activity_min"]),
        "city": str(data["city"]),
        "calorie_goal": int(cal_goal),
    }
    await store.set_profile(message.from_user.id, profile)
    await state.clear()

    temp = await get_city_temperature_c(profile["city"])
    water_goal = calc_water_goal_ml(profile["weight_kg"], profile["activity_min"], temp)
    temp_line = f" (сейчас ~{temp:.1f}°C)" if temp is not None else ""

    await message.answer(
        "✅ Профиль сохранён!\n"
        f"Город: {profile['city']}{temp_line}\n"
        f"Норма воды: {water_goal} мл/день\n"
        f"Цель калорий: {profile['calorie_goal']} ккал/день\n\n"
        "🎉 Всё установлено! Профиль готов к использованию.\n"
        "Теперь можно: /log_water, /log_food, /log_workout, /check_progress"
    )


# -----------------------
# /log_water
# -----------------------


@router.message(Command("log_water"))
async def cmd_log_water(message: Message, command: CommandObject):
    prof = await ensure_profile(message.from_user.id)
    if not prof:
        await message.answer("Сначала настрой профиль: /set_profile")
        return

    arg = (command.args or "").strip()
    ml = parse_int(arg)
    if ml is None or ml <= 0 or ml > 5000:
        await message.answer("Использование: /log_water <мл> (например /log_water 250)")
        return

    await store.add_water(message.from_user.id, ml)

    day = await store.get_day(message.from_user.id)
    temp = await get_city_temperature_c(prof["city"])
    water_goal = calc_water_goal_ml(prof["weight_kg"], prof["activity_min"], temp)

    await message.answer(
        f"✅ Записал {ml} мл воды.\n"
        + progress_text(
            water_goal,
            int(day.get("workout_extra_water_ml", 0)),
            prof["calorie_goal"],
            int(day.get("logged_water_ml", 0)),
            float(day.get("logged_calories", 0)),
            float(day.get("burned_calories", 0)),
        )
    )


# -----------------------
# /log_food (FSM)
# -----------------------


@router.message(Command("log_food"))
async def cmd_log_food(message: Message, state: FSMContext, command: CommandObject):
    prof = await ensure_profile(message.from_user.id)
    if not prof:
        await message.answer("Сначала настрой профиль: /set_profile")
        return

    q = (command.args or "").strip()
    if not q:
        await message.answer("Использование: /log_food <название продукта> (например /log_food банан)")
        return

    info = await search_openfoodfacts(q)
    if not info:
        await message.answer("Не нашёл продукт в базе. Попробуйте другое название.")
        return

    name, kcal_100 = info
    await state.clear()
    await state.update_data(food_name=name, kcal_100=kcal_100)
    await state.set_state(FoodLog.waiting_grams)

    await message.answer(f"🍽️ {name} — примерно {kcal_100:.0f} ккал на 100 г. Сколько грамм вы съели?")


@router.message(FoodLog.waiting_grams)
async def food_grams(message: Message, state: FSMContext):
    grams = parse_float(message.text)
    if grams is None or grams <= 0 or grams > 5000:
        await message.answer("Введите граммы числом (например 150).")
        return

    data = await state.get_data()
    kcal_100 = float(data["kcal_100"])
    name = str(data["food_name"])

    calories = kcal_100 * (grams / 100.0)
    await store.add_food(message.from_user.id, calories)
    await state.clear()

    prof = await ensure_profile(message.from_user.id)
    day = await store.get_day(message.from_user.id)
    temp = await get_city_temperature_c(prof["city"])
    water_goal = calc_water_goal_ml(prof["weight_kg"], prof["activity_min"], temp)

    await message.answer(
        f"✅ Записано: {calories:.0f} ккал ({name}, {grams:.0f} г).\n"
        + progress_text(
            water_goal,
            int(day.get("workout_extra_water_ml", 0)),
            prof["calorie_goal"],
            int(day.get("logged_water_ml", 0)),
            float(day.get("logged_calories", 0)),
            float(day.get("burned_calories", 0)),
        )
    )


# -----------------------
# /log_workout (FSM)
# -----------------------


@router.message(Command("log_workout"))
async def cmd_log_workout(message: Message, state: FSMContext, command: CommandObject):
    prof = await ensure_profile(message.from_user.id)
    if not prof:
        await message.answer("Сначала настрой профиль: /set_profile")
        return

    args = (command.args or "").strip()
    if not args:
        await state.clear()
        await state.set_state(WorkoutLog.waiting_type)
        await message.answer("Введите тип тренировки (например: бег / ходьба / вело / силовая):")
        return

    parts = args.split()
    if len(parts) < 2:
        await message.answer("Использование: /log_workout <тип> <мин> (например /log_workout бег 30)")
        return

    workout_type = " ".join(parts[:-1])
    minutes = parse_int(parts[-1])
    if minutes is None or minutes <= 0 or minutes > 1000:
        await message.answer("Минуты должны быть целым числом. Например: /log_workout бег 30")
        return

    burned = workout_burned_calories(workout_type, minutes, prof["weight_kg"])
    extra_water = workout_extra_water_ml(minutes)
    await store.add_workout(message.from_user.id, burned, extra_water)

    day = await store.get_day(message.from_user.id)
    temp = await get_city_temperature_c(prof["city"])
    water_goal = calc_water_goal_ml(prof["weight_kg"], prof["activity_min"], temp)

    await message.answer(
        f"🏃‍♂️ Тренировка записана: {workout_type}, {minutes} мин.\n"
        f"Сожжено: ~{burned} ккал.\n"
        f"Доп. вода из-за тренировки: +{extra_water} мл к дневной норме.\n\n"
        + progress_text(
            water_goal,
            int(day.get("workout_extra_water_ml", 0)),
            prof["calorie_goal"],
            int(day.get("logged_water_ml", 0)),
            float(day.get("logged_calories", 0)),
            float(day.get("burned_calories", 0)),
        )
    )


@router.message(WorkoutLog.waiting_type)
async def workout_type_step(message: Message, state: FSMContext):
    t = (message.text or "").strip()
    if len(t) < 2:
        await message.answer("Введите тип тренировки текстом. Например: бег")
        return
    await state.update_data(workout_type=t)
    await state.set_state(WorkoutLog.waiting_minutes)
    await message.answer("Сколько минут? (например 30)")


@router.message(WorkoutLog.waiting_minutes)
async def workout_minutes_step(message: Message, state: FSMContext):
    minutes = parse_int(message.text)
    if minutes is None or minutes <= 0 or minutes > 1000:
        await message.answer("Минуты должны быть целым числом. Например: 30")
        return

    data = await state.get_data()
    workout_type = str(data["workout_type"])

    prof = await ensure_profile(message.from_user.id)
    burned = workout_burned_calories(workout_type, minutes, prof["weight_kg"])
    extra_water = workout_extra_water_ml(minutes)
    await store.add_workout(message.from_user.id, burned, extra_water)
    await state.clear()

    day = await store.get_day(message.from_user.id)
    temp = await get_city_temperature_c(prof["city"])
    water_goal = calc_water_goal_ml(prof["weight_kg"], prof["activity_min"], temp)

    await message.answer(
        f"🏃‍♂️ Тренировка записана: {workout_type}, {minutes} мин.\n"
        f"Сожжено: ~{burned} ккал.\n"
        f"Доп. вода из-за тренировки: +{extra_water} мл к дневной норме.\n\n"
        + progress_text(
            water_goal,
            int(day.get("workout_extra_water_ml", 0)),
            prof["calorie_goal"],
            int(day.get("logged_water_ml", 0)),
            float(day.get("logged_calories", 0)),
            float(day.get("burned_calories", 0)),
        )
    )


# -----------------------
# /check_progress, /reset_today
# -----------------------


@router.message(Command("check_progress"))
async def cmd_check_progress(message: Message):
    try:
        prof = await ensure_profile(message.from_user.id)
        if not prof:
            await message.answer("Сначала настрой профиль: /set_profile")
            return

        day = await store.get_day(message.from_user.id)
        temp = await get_city_temperature_c(prof["city"])
        water_goal = calc_water_goal_ml(prof["weight_kg"], prof["activity_min"], temp)
        temp_line = f" (сейчас ~{temp:.1f}°C)" if temp is not None else ""

        await message.answer(
            f"📍 Город: {prof['city']}{temp_line}\n"
            + progress_text(
                water_goal,
                int(day.get("workout_extra_water_ml", 0)),
                prof["calorie_goal"],
                int(day.get("logged_water_ml", 0)),
                float(day.get("logged_calories", 0)),
                float(day.get("burned_calories", 0)),
            )
        )
    except Exception as e:
        logger.error(f"Ошибка при получении прогресса для пользователя {message.from_user.id}: {e}", exc_info=True)
        await message.answer(f"❌ Ошибка при получении прогресса: {str(e)}")


@router.message(Command("reset_today"))
async def cmd_reset_today(message: Message):
    await store.reset_today(message.from_user.id)
    await message.answer("✅ Сегодняшние логи обнулены. /check_progress")


# -----------------------
# Фоллбек на неизвестные команды
# -----------------------


@router.message()
async def fallback(message: Message):
    if message.text and message.text.startswith("/"):
        await message.answer("Неизвестная команда. /help")


def setup_handlers(dp):
    """Подключение всех обработчиков к Dispatcher."""
    dp.include_router(router)
