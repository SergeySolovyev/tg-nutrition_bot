import asyncio
from typing import Optional, Tuple

import aiohttp

from config import OPENWEATHER_API_KEY


async def get_city_temperature_c(city: str) -> Optional[float]:
    """Получить текущую температуру в городе (°C).

    Если задан OPENWEATHER_API_KEY → используем OpenWeatherMap.
    Иначе → используем бесплатный Open-Meteo (без ключа).
    """
    city = (city or "").strip()
    if not city:
        return None

    # 1) OpenWeatherMap
    if OPENWEATHER_API_KEY:
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {"q": city, "appid": OPENWEATHER_API_KEY, "units": "metric"}
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, params=params, timeout=15) as r:
                    if r.status != 200:
                        return None
                    data = await r.json()
                    main = data.get("main") or {}
                    t = main.get("temp")
                    return float(t) if t is not None else None
            except aiohttp.ClientError:
                return None
            except asyncio.TimeoutError:
                return None

    # 2) Fallback: Open-Meteo (no key)
    async with aiohttp.ClientSession() as session:
        try:
            # geocoding
            geocode_url = "https://geocoding-api.open-meteo.com/v1/search"
            async with session.get(
                geocode_url,
                params={"name": city, "count": 1, "language": "ru", "format": "json"},
                timeout=15,
            ) as r:
                if r.status != 200:
                    return None
                geo = await r.json()
                results = geo.get("results") or []
                if not results:
                    return None
                lat = results[0].get("latitude")
                lon = results[0].get("longitude")
                if lat is None or lon is None:
                    return None

            # weather
            forecast_url = "https://api.open-meteo.com/v1/forecast"
            async with session.get(
                forecast_url,
                params={"latitude": lat, "longitude": lon, "current_weather": True},
                timeout=15,
            ) as r:
                if r.status != 200:
                    return None
                w = await r.json()
                cw = w.get("current_weather") or {}
                t = cw.get("temperature")
                return float(t) if t is not None else None
        except aiohttp.ClientError:
            return None
        except asyncio.TimeoutError:
            return None


async def search_openfoodfacts(product_name: str) -> Optional[Tuple[str, float]]:
    """Вернуть (название, ккал/100г) по данным OpenFoodFacts.

    Важно: качество данных OpenFoodFacts бывает разным — для задания это ок.
    """
    q = (product_name or "").strip()
    if not q:
        return None

    url = "https://world.openfoodfacts.org/cgi/search.pl"
    params = {"action": "process", "search_terms": q, "json": "true", "page_size": 1}

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, params=params, timeout=15) as r:
                if r.status != 200:
                    return None
                data = await r.json()
        except aiohttp.ClientError:
            return None
        except asyncio.TimeoutError:
            return None

    products = data.get("products") or []
    if not products:
        return None

    p = products[0] or {}
    name = p.get("product_name") or p.get("generic_name") or "Неизвестно"
    nutr = p.get("nutriments") or {}

    kcal = nutr.get("energy-kcal_100g")
    if kcal is None:
        # иногда есть только kJ, конвертим
        kj = nutr.get("energy-kj_100g")
        kcal = float(kj) / 4.184 if kj is not None else 0.0

    try:
        return str(name), float(kcal)
    except Exception:
        return str(name), 0.0
